<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$route['default_controller'] = 'Products';
$route['404_override'] = '';
$route['p/edit/(:any)'] = 'products/edit/$1';
$route['p/(:any)'] = 'products/show/$1';
// $route['/p/edit/2'] = '/products/edit/2';
$route['register'] = '/users/new_user';
$route['login'] = '/sessions/new_session';
$route['logoff'] = '/sessions/destroy';

//end of routes.php